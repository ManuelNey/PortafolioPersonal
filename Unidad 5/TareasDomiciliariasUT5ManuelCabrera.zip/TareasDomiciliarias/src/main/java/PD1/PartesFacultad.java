package PD1;

public class PartesFacultad {
    private String nombre;
    public PartesFacultad(String nombre)
    {
        this.nombre = nombre;
    }
}
