package Ejercicio9;

public class Ejercicio9 {
    public static  String hannah = "Did Hannah see bees? Hannah did.";
    public static void main(String [] args) {
        //a) El largo del string es 32
        System.out.println(hannah.length());
        //b) Retorna la primera e de la palabra see
        System.out.println(hannah.charAt(12));
        int hannahB = hannah.indexOf("b");
    }
}
