package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class MultiSuma {
    public double multisuma(double valor1, double valor2, double valor3) {
        return valor1 * valor2 + valor3;

    }
}