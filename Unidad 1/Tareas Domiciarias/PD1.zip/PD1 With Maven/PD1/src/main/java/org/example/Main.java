package org.example;

import org.example.MultiSuma;

public class Main {
    public static void main (String[] args) {
        MultiSuma ms = new MultiSuma();
        System.out.println(ms.multisuma(1.0, 2.0, 3.0));
    }
}
