package pd3;

import pd3.TGrafoRedElectrica;
import ta5.TVerticeKevinBacon;
import tdas.TArista;
import tdas.TAristas;
import tdas.TVertice;
import utils.ManejadorArchivosGenerico;
import utils.UtilGrafos;

import java.util.LinkedList;

public class Programa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      // cargar grafo con casas y distancias
        String[] barrios = ManejadorArchivosGenerico.leerArchivo("src/main/java/pd3/barriosPro.txt", false);
        String[] distancias = ManejadorArchivosGenerico.leerArchivo("src/main/java/pd3/distanciasPro.txt", false);
        LinkedList<TVertice> verticesLinkedList = new LinkedList<>();
        LinkedList<TArista> aristasLinkedList = new LinkedList<>();

        for (String barrio : barrios) {
            verticesLinkedList.add(new TVertice<>(barrio, barrio));
        }

        for (String linea : distancias) {
            String[] partesLinea = linea.split(",");
            TArista arista = new TArista(partesLinea[0], partesLinea[1], Integer.parseInt(partesLinea[2]));
            aristasLinkedList.add(arista);
        }
        TGrafoRedElectrica laRed = new TGrafoRedElectrica(verticesLinkedList,aristasLinkedList);
        TAristas mejoresAristas = laRed.mejorRedElectrica();

        String[] lineas = new String[mejoresAristas.size()];
        int i = 0;
        for(TArista arista : mejoresAristas)
        {
            StringBuilder linea = new StringBuilder();
            linea.append(arista.getEtiquetaOrigen());
            linea.append(",");
            linea.append(arista.getEtiquetaDestino());
            linea.append(",");
            linea.append(arista.getCosto());
            lineas[i] = linea.toString();
            i++;
        }
        ManejadorArchivosGenerico.escribirArchivo("src/main/java/pd3/salida.txt", lineas);

        System.out.println("Se van a necesitar "+ mejoresAristas.obtenerCostoTotal() + " metros de cable");
    }
}
