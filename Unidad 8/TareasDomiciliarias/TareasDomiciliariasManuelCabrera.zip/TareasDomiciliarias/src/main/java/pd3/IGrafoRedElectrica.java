package pd3;

import tdas.TAristas;

public interface IGrafoRedElectrica {
 
    public TAristas mejorRedElectrica();

}
