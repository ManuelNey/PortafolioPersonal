package pd3;

import tdas.*;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ocamp
 */
public class TGrafoRedElectrica extends TGrafoNoDirigido implements IGrafoRedElectrica{
    
    public TGrafoRedElectrica(Collection<TVertice> vertices, Collection<TArista> aristas) {
        super(vertices, aristas);
    }

    @Override
    public TAristas mejorRedElectrica() {
        ListaOrdenada<TArista> listaOrdenada = lasAristas.ordenarAristasMejorCoste();
        TAristas aristasAColocar = new TAristas();
        HashMap<Comparable, Set<TVertice>> componentesDelGrafo = new HashMap<>();

        for (Object object : getVertices().values()) {
            TVertice vertice = (TVertice) object;
            Set<TVertice> conjuntoDeVertices = new HashSet<>();
            conjuntoDeVertices.add(vertice);
            componentesDelGrafo.put(vertice.getEtiqueta(), conjuntoDeVertices);
        }
        while (aristasAColocar.size() < getVertices().size() - 1 && !listaOrdenada.esVacia()) {
            TArista aristaElegida = listaOrdenada.popearPrimero();
            Comparable etiquetaA = aristaElegida.getEtiquetaOrigen();
            Comparable etiquetaB = aristaElegida.getEtiquetaDestino();
            Set<TVertice> conjuntoA = componentesDelGrafo.get(etiquetaA);
            Set<TVertice> conjuntoB = componentesDelGrafo.get(etiquetaB);
            Set<TVertice> copiaA = new HashSet<>(conjuntoA); // Hace copia para no modificar el original
            copiaA.retainAll(conjuntoB); //Deferencia de conjuntos

            if (copiaA.isEmpty()) {
                aristasAColocar.add(aristaElegida);
                conjuntoA.addAll(conjuntoB);

                for (TVertice vertice : conjuntoB) {
                    componentesDelGrafo.put(vertice.getEtiqueta(), conjuntoA);
                }
            }
        }
        return aristasAColocar;
    }

}