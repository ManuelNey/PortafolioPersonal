package TA6;

import pd3.TGrafoRedElectrica;
import tdas.TArista;
import tdas.TAristas;
import tdas.TGrafoNoDirigido;
import tdas.TVertice;
import utils.ManejadorArchivosGenerico;

import java.util.LinkedList;

public class Main {
    public static void main(String[] args)
    {
        //Prueba de ari2 y vrt2
        String[] vertices = ManejadorArchivosGenerico.leerArchivo("src/main/java/TA6/vert2.txt", false);
        String[] aristas = ManejadorArchivosGenerico.leerArchivo("src/main/java/TA6/ari2.txt", false);
        LinkedList<TVertice> verticesLinkedList = new LinkedList<>();
        LinkedList<TArista> aristasLinkedList = new LinkedList<>();

        for (String vertice : vertices) {
            verticesLinkedList.add(new TVertice<>(vertice, vertice));
        }

        for (String linea : aristas) {
            String[] partesLinea = linea.split(",");
            TArista arista = new TArista(partesLinea[0], partesLinea[1], Integer.parseInt(partesLinea[2]));
            aristasLinkedList.add(arista);
        }
        TGrafoNoDirigido grafo = new TGrafoNoDirigido(verticesLinkedList,aristasLinkedList);
        TAristas mejoresAristas = grafo.Prim().getLasAristas();

        String[] lineas = new String[mejoresAristas.size()];
        int i = 0;
        for(TArista arista : mejoresAristas)
        {
            StringBuilder linea = new StringBuilder();
            linea.append(arista.getEtiquetaOrigen());
            linea.append(",");
            linea.append(arista.getEtiquetaDestino());
            linea.append(",");
            linea.append(arista.getCosto());
            lineas[i] = linea.toString();
            i++;
        }
        ManejadorArchivosGenerico.escribirArchivo("src/main/java/TA6/salidaVert2yAri2.txt", lineas);
        //Se van a escribir en formato de un dirigido con ambas aristas
        //Si queremos hacer que solo se escriban una vez o limpiamos la lista del getter o hacemos un metodo
        // en las aristas que elimine los duplicados pero no vamos a modificar las aristas internas del grafo
        //Sino se podría recorrer en numeros impares la lista y agregar la linea impar ya que las aristas ahora osn comparables y 2 son iguales si tienen los datos inversos de origen y destino con mismo coste

        //conexiones2 y aeropuertos
        String[] verticesB = ManejadorArchivosGenerico.leerArchivo("src/main/java/TA6/aeropuertos_2.txt", false);
        String[] aristasB = ManejadorArchivosGenerico.leerArchivo("src/main/java/TA6/conexiones_2.txt", false);
        LinkedList<TVertice> verticesLinkedListB = new LinkedList<>();
        LinkedList<TArista> aristasLinkedListB = new LinkedList<>();

        for (String vertice : verticesB) {
            verticesLinkedListB.add(new TVertice<>(vertice, vertice));
        }

        for (String linea : aristasB) {
            String[] partesLinea = linea.split(",");
            TArista arista = new TArista(partesLinea[0], partesLinea[1], Integer.parseInt(partesLinea[2]));
            aristasLinkedListB.add(arista);
        }
        TGrafoNoDirigido grafoB = new TGrafoNoDirigido(verticesLinkedListB,aristasLinkedListB);
        TAristas mejoresAristasKruskal = grafoB.Kruskal().getLasAristas();

        String[] lineasB = new String[mejoresAristasKruskal.size()];
        int j = 0;
        for(TArista arista : mejoresAristasKruskal)
        {
            StringBuilder linea = new StringBuilder();
            linea.append(arista.getEtiquetaOrigen());
            linea.append(",");
            linea.append(arista.getEtiquetaDestino());
            linea.append(",");
            linea.append(arista.getCosto());
            lineasB[j] = linea.toString();
            j++;
        }
        ManejadorArchivosGenerico.escribirArchivo("src/main/java/TA6/salidaAeropuerto", lineasB);

    }
}
