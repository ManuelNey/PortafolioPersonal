package ta5;

import tdas.TArista;
import utils.ManejadorArchivosGenerico;

import java.util.Collection;
import java.util.LinkedList;

public class MainTA5 {
    public static void main(String[] args) {
        String[] actores = ManejadorArchivosGenerico.leerArchivo("src/main/java/ta5/actores.csv", false);
        String[] enPelicula = ManejadorArchivosGenerico.leerArchivo("src/main/java/ta5/en_pelicula.csv", false);

        // Usamos directamente TVerticeKevinBacon para que no se pierda el tipo
        LinkedList<TVerticeKevinBacon> verticesKevinBacon = new LinkedList<>();
        LinkedList<TArista> aristasKevinBaconLinkedList = new LinkedList<>();

        // Cargar actores como TVerticeKevinBacon
        for (String actor : actores) {
            verticesKevinBacon.add(new TVerticeKevinBacon(actor, actor));
        }

        // Cargar aristas desde archivo
        for (String linea : enPelicula) {
            String[] partesLinea = linea.split(",");
            TArista enPeli = new TArista(partesLinea[0], partesLinea[1], Integer.parseInt(partesLinea[2]));
            aristasKevinBaconLinkedList.add(enPeli);
        }

        // Cast explícito a Collection<TVertice> al crear el grafo
        TGrafoKevinBacon grafoKevinBacon = new TGrafoKevinBacon((Collection) verticesKevinBacon, aristasKevinBaconLinkedList);

        // Probar el cálculo del número de Bacon

        grafoKevinBacon.calcularNumeroDeTodos();
        System.out.println("Número de Bacon de Brad_Pitt: " + grafoKevinBacon.numBacon("Brad_Pitt"));

    }
}
