package ta5;

import tdas.*;

import java.util.Collection;
import java.util.LinkedList;
import java.util.Queue;

public class TGrafoKevinBacon extends TGrafoNoDirigido implements IGrafoKevinBacon {

    public TGrafoKevinBacon(Collection<TVerticeKevinBacon> vertices, Collection<TArista> aristas) {
        super();
        //Se crea el grafo vacio porque si lo intentamos crear como un grafo normal perdomos datos, al grafo estar modelado para copiar vertices normales y no inseertarlos directamentes

        for (TVerticeKevinBacon vertice : vertices) {
            insertarVertice(vertice); //Ahora si insertamos los datos
        }

        for (TArista arista : aristas) {
            this.insertarArista(arista);
        }
    }

    public void calcularNumeroDeTodos() {
        desvisitarVertices();

        TVerticeKevinBacon kevinBacon = (TVerticeKevinBacon) getVertices().get("Kevin_Bacon");
        if (kevinBacon == null) {
            System.out.println("Kevin_Bacon no está hoy");
            return;
        }

        kevinBacon.setBacon(0);
        kevinBacon.setVisitado(true);

        Queue<TVerticeKevinBacon> cola = new LinkedList<>();
        cola.add(kevinBacon);

        while (!cola.isEmpty()) {
            TVerticeKevinBacon actual = cola.poll();
            int baconActual = actual.getBacon();

            for (Object object : actual.getAdyacentes()) {
                TAdyacencia ady = (TAdyacencia) object;
                TVerticeKevinBacon destino = (TVerticeKevinBacon) ady.getDestino();

                if (!destino.getVisitado()) {
                    destino.setVisitado(true);
                    destino.setBacon(baconActual + 1);
                    cola.add(destino);
                }
            }
        }
    }

    @Override
    public int numBacon(Comparable actor) {
        IVertice vert = (IVertice) getVertices().get(actor);
        if (vert instanceof TVerticeKevinBacon vKB) {
            return vKB.getBacon();
        }
        return -1;
    }

    public int numBacon2(Comparable actor) {
        IVertice vert = (IVertice) getVertices().get(actor);
        if (vert == null) {
            return -1;
        }
        return mejorCamino("Kevin_Bacon", actor).getCostoTotal().intValue();
    }

}
