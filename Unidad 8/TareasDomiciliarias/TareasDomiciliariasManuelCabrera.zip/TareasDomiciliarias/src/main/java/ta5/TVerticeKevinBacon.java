package ta5;

import tdas.IAdyacencia;
import tdas.IVertice;
import tdas.TAdyacencia;
import tdas.TVertice;

import java.util.LinkedList;
import java.util.Queue;

public class TVerticeKevinBacon extends TVertice implements IVerticeKevinBacon {

    private int Bacon;

    public TVerticeKevinBacon(Comparable unaEtiqueta, Object datos) {
        super(unaEtiqueta, datos);
    }

    public int cacularBacon() {
        return getBaconRecursivo(0);
    }

    public int getBaconRecursivo(int gradoBaconAnterior) {
        setVisitado(true);
        LinkedList<TAdyacencia> ady = this.getAdyacentes();
        if (this.getEtiqueta().compareTo("Kevin_Bacon") == 0) {
            return gradoBaconAnterior;
        }
        int mejorConexion = Integer.MAX_VALUE;
        for (IAdyacencia destino : ady) {
            if (!destino.getDestino().getVisitado()) {
                int resultado = ((TVerticeKevinBacon) destino.getDestino()).getBaconRecursivo(gradoBaconAnterior + 1);
                mejorConexion = Math.min(resultado, mejorConexion);
            }
        }
        return mejorConexion;
    }

    @Override
    public int getBacon() {
        return Bacon;
    }

    @Override
    public void setBacon(int newBacon) {
        Bacon = newBacon;
    }
}
