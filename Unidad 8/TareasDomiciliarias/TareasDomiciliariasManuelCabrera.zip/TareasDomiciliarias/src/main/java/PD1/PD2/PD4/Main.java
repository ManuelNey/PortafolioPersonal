package PD1.PD2.PD4;

import tdas.*;
import utils.UtilGrafos;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        // PD1
        TVertice vA = new TVertice("A", "A");
        TVertice vB = new TVertice("B", "B");
        TVertice vC = new TVertice("C", "C");
        TVertice vD = new TVertice("D", "D");
        TVertice vE = new TVertice("E", "E");

        Collection<IVertice> vertices = new LinkedList<>();
        vertices.add(vA);
        vertices.add(vB);
        vertices.add(vC);
        vertices.add(vD);
        vertices.add(vE);

        Collection<IArista> aristas = new LinkedList<>();
        aristas.add(new TArista("A", "B", 4));
        aristas.add(new TArista("A", "C", 2));
        aristas.add(new TArista("B", "C", 15));
        aristas.add(new TArista("B", "D", 10));
        aristas.add(new TArista("C", "E", 3));
        aristas.add(new TArista("C", "D", 4));
        aristas.add(new TArista("D", "E", 1));
        aristas.add(new TArista("E", "B", 4));
        aristas.add(new TArista("A", "E", 1));

        TGrafoNoDirigido<String> grafo = new TGrafoNoDirigido<>(vertices, aristas);

        UtilGrafos.imprimirMatrizMejorado(UtilGrafos.obtenerMatrizCostos(grafo.getVertices()), grafo.getVertices(), "Grafo Normal");

        TGrafoNoDirigido<String> prim = grafo.Prim(); //Partiendo de A

        UtilGrafos.imprimirMatrizMejorado(UtilGrafos.obtenerMatrizCostos(prim.getVertices()), prim.getVertices(), "Grafo Prim");

        //pd2
        TGrafoNoDirigido<String> kruskal = grafo.Kruskal();

        UtilGrafos.imprimirMatrizMejorado(UtilGrafos.obtenerMatrizCostos(kruskal.getVertices()), kruskal.getVertices(), "Grafo Kruskal");

        /*
        Comparación entre ambos:
        Ambos algoritmos generan van a generar el arbol abarcado de coste minimo, pero lo hacen de maneras distintas.
        Prim comienza con un vértice va agrando las conexiones que tiene los vertices ya conextados, básicamente expande el árbol agregando la mejor arista posible (la de coste menor si así lo queremos) que conectan con los vértices ya alcanzados.
        Kruscal funciona ordenando cada arista y colocandola una por una hasta tener un grafo conexo aciclico uniendo de a uno los componentes conexos.

        Estructuras de datos utilizadas en kruscal:
        La implementación de Kruskal que hice utiliza una lista ordenada de aristas, que se obtiene recorriendo todos los vértices y adyacencias, evitando duplicados. Luego se usa una estructura de conjuntos para saber los componentes conexos así se generan ciclos.
        El orden de tiempo es O(N log N) por las aristas etarían ordenadas que es el orden que tiene kruskal, donde E es la cantidad de aristas. Las operaciones find y union tienen tiempo casi constante si se utiliza compresión de caminos.
        */

        // PD4

        System.out.println("Hay arista de A B: " + grafo.conectadosDirecto("A", "B"));
        System.out.println("Hay camino de A B: " + grafo.conectados("A", "B"));


        System.out.println("Hay arista de A D: " + grafo.conectadosDirecto("D", "A"));
        System.out.println("Hay camino de A D: " + grafo.conectados("A","D"));

    }
}
