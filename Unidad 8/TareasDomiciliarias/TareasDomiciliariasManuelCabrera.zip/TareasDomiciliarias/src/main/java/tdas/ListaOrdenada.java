package tdas;

public class ListaOrdenada<T> extends Lista<T> {

    @Override
    public void insertar(T dato, Comparable clave) {
        Nodo nuevoNodo = new Nodo(clave, dato);


        if (getPrimero() == null) {
            nuevoNodo.setSiguiente(null);
            this.SetPrimero(nuevoNodo);
        }
        else {

            if (this.getCodigoPrimero().compareTo(clave) >= 0) {
                nuevoNodo.setSiguiente(getPrimero());
                this.SetPrimero(nuevoNodo);
                return;
            }

            Nodo actual = getPrimero();
            while (actual.getSiguiente() != null && this.getCodigo(actual.getSiguiente()).compareTo(clave) < 0){
                actual = actual.getSiguiente();
            }

            nuevoNodo.setSiguiente(actual.getSiguiente());
            actual.setSiguiente(nuevoNodo);
        }
    }

    public void insertarSinDuplicados(T dato, Comparable clave) {
        Nodo nuevoNodo = new Nodo(clave, dato);

        if (getPrimero() == null) {
            nuevoNodo.setSiguiente(null);
            this.SetPrimero(nuevoNodo);
        } else {
            // Si la clave ya existe en el primero, no se inserta
            if (this.getCodigoPrimero().compareTo(clave) == 0) {
                return;
            }

            // Si la clave es menor, insertar al principio
            if (this.getCodigoPrimero().compareTo(clave) > 0) {
                nuevoNodo.setSiguiente(getPrimero());
                this.SetPrimero(nuevoNodo);
                return;
            }

            Nodo actual = getPrimero();
            while (actual.getSiguiente() != null) {
                int comparacion = this.getCodigo(actual.getSiguiente()).compareTo(clave);

                if (comparacion == 0) {
                    return; // No se inserta si ya existe la clave
                } else if (comparacion > 0) {
                    break;
                }

                actual = actual.getSiguiente();
            }

            nuevoNodo.setSiguiente(actual.getSiguiente());
            actual.setSiguiente(nuevoNodo);
        }
    }
}
