package tdas;

import java.util.*;

public class TGrafoNoDirigido<T> extends TGrafoDirigido<T> implements IGrafoNoDirigido {
    protected TAristas lasAristas = new TAristas();

    /**
     *
     * @param vertices
     * @param aristas
     */
    public TGrafoNoDirigido(Collection<IVertice> vertices, Collection<IArista> aristas) {
        super(vertices, aristas);
        lasAristas.insertarAmbosSentidos(aristas);

    }

    public TGrafoNoDirigido() {
        this.vertices = new HashMap<>();
        this.lasAristas = new TAristas(); // o lo que uses
    }


    @Override
    public boolean insertarArista(IArista arista) {
        boolean tempbool = false;
        TArista arInv = new TArista(arista.getEtiquetaDestino(), arista.getEtiquetaOrigen(), arista.getCosto());
        tempbool = (super.insertarArista(arista) && super.insertarArista(arInv));
        return tempbool;
    }

    public TAristas getLasAristas() {
        return lasAristas;
    }


    public TGrafoNoDirigido PrimSinLasAristas() { //Funciona correctamente pero recorre cada posible arista y consulta por ella
        Set<TVertice> U = new HashSet<>();
        Set<IVertice> V = new HashSet<>(this.getVertices().values());
        Set<TArista> T = new HashSet<>();
        TVertice verticeInicial = (TVertice) getVertices().values().iterator().next();
        U.add(verticeInicial);
        while (!U.containsAll(V)) {
            TArista aristaMinima = null;

            for (TVertice u : U) {
                LinkedList<TAdyacencia> aristas = u.getAdyacentes();
                for (TAdyacencia ady : aristas) {
                    IVertice destino = ady.getDestino();

                    if (!U.contains(destino)) {
                        TArista posibleArista = new TArista(
                                u.getEtiqueta(), destino.getEtiqueta(), ady.getCosto());
                        if (aristaMinima == null || posibleArista.getCosto() < aristaMinima.getCosto()) {
                            aristaMinima = posibleArista;
                        }
                    }
                }
            }
            if (aristaMinima != null) {
                T.add(aristaMinima);
                U.add((TVertice) getVertices().get(aristaMinima.getEtiquetaDestino()));
            } else {
                throw new IllegalArgumentException("El grafo no es conexo");
            }
        }
        return new TGrafoNoDirigido(U, T);
    }


    @Override
    public TGrafoNoDirigido Prim() {
        HashSet<Comparable> verticesNoVisitados = new HashSet<>(vertices.keySet());
        HashSet<Comparable> verticesVisitados = new HashSet<>();
        HashSet<TArista> mejoresAristas = new HashSet<>();
        verticesVisitados.add(verticesNoVisitados.iterator().next());
        verticesNoVisitados.remove(verticesNoVisitados.iterator().next());
        while (verticesNoVisitados.size() > 0) {
            TArista mejorArista = lasAristas.buscarMin(verticesVisitados, verticesNoVisitados);
            if (mejorArista == null) {
                throw new IllegalArgumentException("Grafo no conexo");
            }
            mejoresAristas.add(mejorArista);
            verticesNoVisitados.remove(mejorArista.getEtiquetaDestino());
            verticesVisitados.add(mejorArista.getEtiquetaDestino());
        }
        return new TGrafoNoDirigido(vertices.values(), mejoresAristas);
    }

    @Override
    public TGrafoNoDirigido Kruskal() {
        //Hay que revisar que le grafo sea conexoooo por si acaso sino quedamos en bucle
        ListaOrdenada<TArista> listaOrdenada = lasAristas.ordenarAristasMejorCoste();
        TAristas aristasAColocar = new TAristas();
        HashMap<Comparable, Set<TVertice>> componentesDelGrafo = new HashMap<>();

        for (Object object : getVertices().values()) {
            TVertice vertice = (TVertice) object;
            Set<TVertice> conjuntoDeVertices = new HashSet<>();
            conjuntoDeVertices.add(vertice);
            componentesDelGrafo.put(vertice.getEtiqueta(), conjuntoDeVertices);
        }
        while (aristasAColocar.size() < getVertices().size() - 1 && !listaOrdenada.esVacia()) {
            TArista aristaElegida = listaOrdenada.popearPrimero();
            Comparable etiquetaA = aristaElegida.etiquetaOrigen;
            Comparable etiquetaB = aristaElegida.etiquetaDestino;
            Set<TVertice> conjuntoA = componentesDelGrafo.get(etiquetaA);
            Set<TVertice> conjuntoB = componentesDelGrafo.get(etiquetaB);
            Set<TVertice> copiaA = new HashSet<>(conjuntoA); // Hace copia para no modificar el original
            copiaA.retainAll(conjuntoB); //Deferencia de conjuntos

            if (copiaA.isEmpty()) {
                aristasAColocar.add(aristaElegida);
                conjuntoA.addAll(conjuntoB);

                for (TVertice vertice : conjuntoB) {
                    componentesDelGrafo.put(vertice.getEtiqueta(), conjuntoA);
                }
            }
        }
        LinkedList<IVertice> vertices = new LinkedList<>();
        Collection<IVertice> listaVertices = getVertices().values();

        for (IVertice vertice : listaVertices) {
            vertices.add(vertice);
        }
        return new TGrafoNoDirigido(vertices, aristasAColocar);
    }

    @Override
    public LinkedList<TVertice> bea(Comparable etiquetaOrigen) {
        if (etiquetaOrigen == null || getVertices().get(etiquetaOrigen) == null) {
            return null;
        }
        TVertice vertice = (TVertice) getVertices().get(etiquetaOrigen);
        LinkedList<TVertice> vertices = new LinkedList<>();
        vertice.bea(vertices);
        return vertices;
    }

    @Override
    public LinkedList<TVertice> bea() {
        desvisitarVertices();
        LinkedList<TVertice> verticesRecorridos = new LinkedList<>();
        for (Object v : super.getVertices().values()) {
            TVertice vertice = (TVertice) v;
            if (!vertice.getVisitado()) {
                verticesRecorridos.addAll(bea(vertice.getEtiqueta()));
            }
        }
        return verticesRecorridos;
    }

    public LinkedList<TVertice> puntoArticulacion() {
        int bpf = 1;
        LinkedList<TVertice> puntos = new LinkedList<>();

        desvisitarVertices();
        for (Object o : getVertices().values()) {
            TVertice vertice = (TVertice) o;
            if (!vertice.getVisitado()) {
                bpf = vertice.cargarPuntosArticulacion(null, puntos, bpf);
            }
        }
        return puntos;
    }

    public LinkedList<TVertice> puntoArticulacion(Comparable origen) {

        if (origen == null) {
            return null;
        }
        Object verticeObj = getVertices().get(origen);
        if (verticeObj == null) {
            return null;
        }
        TVertice vertice = (TVertice) verticeObj;
        desvisitarVertices();
        LinkedList<TVertice> puntos = new LinkedList<>();
        vertice.cargarPuntosArticulacion(null, puntos, 1);
        return puntos;
    }

    public int cantidadComponentesConexos() {
        desvisitarVertices();
        int cantidadComponentes = 0;
        for (Object v : super.getVertices().values()) {
            TVertice vertice = (TVertice) v;
            if (!vertice.getVisitado()) {
                bea(vertice.getEtiqueta());
                cantidadComponentes++;
            }
        }
        return cantidadComponentes;
    }

    public Boolean esConexo() {
        if (!getVertices().values().iterator().hasNext()) return null;
        desvisitarVertices();
        TVertice verticeCualquiera = (TVertice) getVertices().values().iterator().next();
        LinkedList<TVertice> vertices = new LinkedList<>();
        verticeCualquiera.bea(vertices);
        if (vertices.size() != getVertices().size()) {
            return false;
        }
        return true;
    }

    public boolean conectadosDirecto(Comparable origen, Comparable destino) {
        if (origen == null || destino == null || getVertices().get(origen) == null || getVertices().get(destino) == null) {
            return false;
        }
        return existeArista(origen, destino) || existeArista(destino, origen);
    }
    public boolean conectados(Comparable origen, Comparable destino) {
        if (origen == null || destino == null || getVertices().get(origen) == null || getVertices().get(destino) == null) {
            return false;
        }
        desvisitarVertices();
        LinkedList<IVertice> hijosEnBPF = new LinkedList<>();
        getVertices().get(origen).bpf(hijosEnBPF);
        if (hijosEnBPF.contains(getVertices().get(destino)))
        {
            return true;
        }
        return false;
    }
}
