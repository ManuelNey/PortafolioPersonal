package tdas;

import utils.UtilGrafos;

import java.util.Collection;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        // Crear vértices
        TVertice vA = new TVertice("A", "A");
        TVertice vB = new TVertice("B", "B");
        TVertice vC = new TVertice("C", "C");
        TVertice vD = new TVertice("D", "D");
        TVertice vG = new TVertice("G", "G");
        TVertice vF = new TVertice("F", "F");
        TVertice vE = new TVertice("E", "E");

        // Agregar vértices a colección
        Collection<TVertice> vertices = new LinkedList<>();
        vertices.add(vA);
        vertices.add(vB);
        vertices.add(vC);
        vertices.add(vD);
        vertices.add(vE);
        vertices.add(vG);
        vertices.add(vF);

        // Crear aristas dirigidas
        Collection<TArista> aristas = new LinkedList<>();
        aristas.add(new TArista("A", "B", 2));
        aristas.add(new TArista("A", "C", 3));
        aristas.add(new TArista("C", "D", 1));
        aristas.add(new TArista("D", "E", 4));
        aristas.add(new TArista("E", "F", 10));
        aristas.add(new TArista("F", "G", 5));
        aristas.add(new TArista("G", "E", 6));
        aristas.add(new TArista("C", "B", 2));

        // Crear grafo dirigido
        TGrafoNoDirigido grafo = new TGrafoNoDirigido(vertices, aristas);

        LinkedList<TVertice> vertices1 = grafo.bea();
        for (TVertice v : vertices1) {
            System.out.println(v.getEtiqueta());
        }

        System.out.println("Puntos de articulacion desde A:");
        // Inicializar valores y buscar puntos de articulación
        LinkedList<TVertice> puntosArticulacion = grafo.puntoArticulacion("A");
        for (TVertice v : puntosArticulacion) {
            System.out.println(v.getEtiqueta());
        }

        TGrafoNoDirigido grafoKruskal = grafo.Kruskal();
        UtilGrafos.imprimirMatrizMejorado(UtilGrafos.obtenerMatrizCostos(grafoKruskal.getVertices()), grafoKruskal.getVertices(), "Kruskal");

        TGrafoNoDirigido grafoPrim = grafo.PrimSinLasAristas();
        UtilGrafos.imprimirMatrizMejorado(UtilGrafos.obtenerMatrizCostos(grafoPrim.getVertices()), grafoPrim.getVertices(), "Prim");

        TGrafoNoDirigido grafoPrimVersionCompleta = grafo.Prim();
        UtilGrafos.imprimirMatrizMejorado(UtilGrafos.obtenerMatrizCostos(grafoPrimVersionCompleta.getVertices()), grafoPrimVersionCompleta.getVertices(), "Prim full version");


        System.out.println(grafo.cantidadComponentesConexos());
        System.out.println(grafo.esConexo());
        System.out.println("Hay arista de A B: " + grafo.conectadosDirecto("A", "B"));
        System.out.println("Hay camino de A B: " + grafo.conectados("A", "B"));
        grafo.eliminarVertice("E");
        System.out.println(grafo.cantidadComponentesConexos());
        System.out.println(grafo.esConexo());
        System.out.println("Hay arista de A D: " + grafo.conectadosDirecto("D", "A"));
        System.out.println("Hay camino de A D: " + grafo.conectados("A","D"));
        grafo.eliminarVertice("C");
        System.out.println(grafo.cantidadComponentesConexos());
        System.out.println(grafo.esConexo());
        grafo.eliminarVertice("D");
        System.out.println(grafo.cantidadComponentesConexos());
        System.out.println(grafo.esConexo());
    }
}
