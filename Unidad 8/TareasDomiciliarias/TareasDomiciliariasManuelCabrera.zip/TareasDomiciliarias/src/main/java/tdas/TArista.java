package tdas;

public class TArista implements IArista, Comparable{

    protected Comparable etiquetaOrigen;
    protected Comparable etiquetaDestino;
    protected double costo;

    public TArista(Comparable etiquetaOrigen, Comparable etiquetaDestino, double costo) {
        this.etiquetaOrigen = etiquetaOrigen;
        this.etiquetaDestino = etiquetaDestino;
        this.costo = costo;
    }

    
    @Override
    public Comparable getEtiquetaOrigen() {
        return etiquetaOrigen;
    }

    @Override
    public void setEtiquetaOrigen(Comparable etiquetaOrigen) {
        this.etiquetaOrigen = etiquetaOrigen;
    }

    @Override
    public Comparable getEtiquetaDestino() {
        return etiquetaDestino;
    }

    @Override
    public void setEtiquetaDestino(Comparable etiquetaDestino) {
        this.etiquetaDestino = etiquetaDestino;
    }

    @Override
    public double getCosto() {
        return costo;
    }

    @Override
    public void setCosto(double costo) {
        this.costo = costo;
    }

    public TArista aristaInversa (){
        return new TArista(this.getEtiquetaDestino(), this.getEtiquetaOrigen(),this.getCosto());
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true; //Misma intancia
        if (o == null || getClass() != o.getClass())
        {
            return false; //Distinto tipo
        }
        TArista arista = (TArista) o;
        return (etiquetaOrigen.equals(arista.etiquetaOrigen) && etiquetaDestino.equals(arista.etiquetaDestino))
                || (etiquetaOrigen.equals(arista.etiquetaDestino) && etiquetaDestino.equals(arista.etiquetaOrigen)); // si es no dirigido
    }

    @Override
    public int hashCode() {
        return etiquetaOrigen.hashCode() + etiquetaDestino.hashCode(); // esto sirve para que las simetricas tengan el mismo hashcode
    }

    @Override
    public int compareTo(Object ota) {
        if (this == ota){
            return 0; //Misma intancia
        }
        TArista otra = (TArista) ota;
        int comparacionCosto = Double.compare(this.costo, otra.costo);
        if (comparacionCosto != 0) {
            return comparacionCosto;
        }

        // Si los costos son iguales compararo por etiqueta de origen
        int comparacionOrigen = this.etiquetaOrigen.toString().compareTo(otra.etiquetaOrigen.toString());
        if (comparacionOrigen != 0) {
            return comparacionOrigen;
        }

        //Sino comparo por destino
        return this.etiquetaDestino.toString().compareTo(otra.etiquetaDestino.toString());
    }
}
