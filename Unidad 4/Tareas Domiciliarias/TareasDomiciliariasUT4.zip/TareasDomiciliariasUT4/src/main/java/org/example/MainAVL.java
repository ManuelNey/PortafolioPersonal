package org.example;

import tdas.ArbolAVL;

public class MainAVL {
    public static void main(String[] args) {
        ArbolAVL arbol = new ArbolAVL();
        arbol.insertar(1,1);
        arbol.insertar(2,2);
        arbol.insertar(3,3);
    }
}
