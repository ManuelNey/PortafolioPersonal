package UT4_PD0;

import java.util.Map;

public interface INodoOperacion extends IElemento {
    float calcular(Map<String, Integer> variables);
}
