package UT4_PD0;

import java.util.Map;

public interface INodoVariable extends IElemento {
    float calcular(Map<String, Integer> variables);
}
