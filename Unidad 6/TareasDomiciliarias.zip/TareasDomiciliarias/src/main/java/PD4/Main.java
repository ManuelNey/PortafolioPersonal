package PD4;

public class Main {
    public static void main(String[] args) {
        String rutaArchivo = "src/main/java/PD3/libro.txt";
        ContadorFrecuenciasPalabras.palabrasConcurrentes(rutaArchivo);
    }
}